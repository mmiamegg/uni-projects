package marks.model;

/**
 *
 * @author Mia Megan Gail Macasero (12127091)
 */
public class ConnectionException extends RuntimeException {
    
    public ConnectionException( String message, Throwable cause ) {
        super(message,cause);
    }
    
}
