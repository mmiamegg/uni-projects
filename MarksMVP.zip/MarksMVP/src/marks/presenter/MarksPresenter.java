package marks.presenter;

import marks.model.IQuery;
import marks.model.QueryException;
import marks.model.IConnect;
import marks.model.ConnectionException;
import marks.model.Marks;

import marks.view.IView;

import java.util.List;

// The queries that are available for the address book
import static marks.model.MarksModel.Query.*;

/**
 * MarksPresenter provides a presenter implementation of the MVP pattern for
 the address marks
 * 
 * @author Mia Megan Gail Macasero (12127091)
 */

public class MarksPresenter {
    
    private static class ViewModel {
        List<Marks> model;
        Marks current;
        int index;
        int n;
        
        ViewModel() {
        }
        
        void set( List<Marks> m ) {
            model = m;
            index = 0;
            n = model.size();
            current = model.get(index);
        }
        
        IndexedMarks previous() {
            if (--index < 0 )
                index = n-1;
            return new IndexedMarks( model.get(index), index+1, n );              
        }
        
        IndexedMarks next() {
            if (++index > n-1 )
                index = 0;
            return new IndexedMarks( model.get(index), index+1, n );            
        }
        
        IndexedMarks current() {
            return new IndexedMarks( model.get(index), index+1, n );  
        }
    }

    // The context for model and view interaction
    IView view;
    IQuery queries;
    IConnect connector;
    ViewModel viewModel;

    /**
     * Create a presenter instance. As there is a circular dependency between the
     * view and the presenter, only the presenters model dependencies are injected 
     * via the constructor - the view dependency is explictly injected via the
     * bind() method.
     * @param iq iquery
     * @param ic iconnect
     */
    public MarksPresenter(IQuery iq, IConnect ic) {
        // intialise model access
        queries = iq;
        connector = ic;
        // initialise the browsing context
        viewModel = new ViewModel();
    }

    /**
     * Set the view dependency for the presenter  
     * @param iv the view
     */
    public void bind(IView iv) {
        view = iv;
    }

    /**
     * For the records being browsed, make the previous record the current
     * record and display it, together with its position in the browsing
     * context. If the current record is the first record, the last record will
     * become the current record.
     */
    
    /********************************************/
    /*          BROWSE FUNCTIONALITIES          */
    /********************************************/
    
    public void showPrevious() {
        view.displayRecord( viewModel.previous() );
    }

    /**
     * For the records being browsed, make the next record the current record 
     * and display it, together with its position in the browsing
     * context. If the current record is the last record, the first record will 
     * become the current record.
     */
    public void showNext() {
        view.displayRecord( viewModel.next() );
    }
    
    /***********************************************/
    /*          DISPLAY RECORDS TO BROWSE          */
    /***********************************************/
    
    private void displayCurrentRecord(List results) {
        if (results.isEmpty()) {
            view.displayMessage("No records found");
            view.setBrowsing(false);
            return;
        }
        viewModel.set(results);
        view.displayRecord(viewModel.current());
        view.setBrowsing(true);
    }
    
    
    /********************************************/
    /*          SEARCH FUNCTIONALITIES          */
    /********************************************/
    
    /**
     * Set the browsing context to contain all records in the address book with 
     * a specified last name. Display he first record or an error message if no 
     * records are found.
     * @param studentID the name being searched for.
     * @throws IllegalArgumentException if lastName is an empty string.
     */
    
    public void selectByStudentID(String studentID) throws IllegalArgumentException {
        // No checking is performed for lastName being null, as this constitutes 
        // a programming error and having the program crash (with a stack trace) 
        // is reasonable in this case.
        if (studentID.equals("")) {
            throw new IllegalArgumentException("Argument must not be an empty string");
        }
        try {
            // select a student from the database
            List results = queries.select(STUDENTID, studentID);
            // display student records on the browser
            List<Marks> marks = results;
            displayCurrentRecord(results);
            
        } catch (QueryException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }
    
    public void selectByTolerance(int tolerance) throws IllegalArgumentException {
        // No checking is performed for lastName being null, as this constitutes 
        // a programming error and having the program crash (with a stack trace) 
        // is reasonable in this case.
        if (tolerance == 0) {
            throw new IllegalArgumentException("Argument must not be an empty string");
        }
        try {
            List results = queries.select(TOLERANCE, tolerance);
            //displayCurrentRecord(results);
            List<Marks> marks = results;
            displayCurrentRecord(results);
            view.displayAllArea(marks);
            view.setBrowsing(true);
        } catch (QueryException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }
    
    public void selectByRange(int rFrom, int rTo) throws IllegalArgumentException {
        // No checking is performed for lastName being null, as this constitutes 
        // a programming error and having the program crash (with a stack trace) 
        // is reasonable in this case.
        if (rFrom == 0 || rTo == 0) {
            throw new IllegalArgumentException("Argument must not be zero");
        }
        try {
            List results = queries.select(RANGE, rFrom, rTo);
            //displayCurrentRecord(results);
            List<Marks> marks = results;
            displayCurrentRecord(results);
            view.displayAllArea(marks);
            view.setBrowsing(true);
        } catch (QueryException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Set the browsing context to  all records in the address book and display 
     * the first record.
     */
    public void selectAll() {
        try {
            List results = queries.select(ALL);
            List<Marks> marks = results;
            displayCurrentRecord(results);
            view.displayAllArea(marks);
        } catch (QueryException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Insert a new entry into the marks table.
     * @param studentID id of student
     * @param assignment1 assignment 1
     * @param assignment2 assignment 2
     * @param exam exam
     * @param total total of all assessments
     * @param grade computation of all assessments
     * @throws IllegalArgumentException if any of the parameters are empty strings
     */
    public void insert(String studentID, int assignment1, int assignment2, int exam, int total, String grade) throws IllegalArgumentException {
        // No checking is performed for parameters being null, as this constitutes 
        // a programming error and having the program crash (with a stack trace) 
        // is reasonable in this case.
        if (studentID.equals("") || assignment1 == 0 || assignment2 == 0 || exam == 0 || total == 0 || grade.equals("")) {
            throw new IllegalArgumentException("Arguments must not contain an empty string");
        }
        try {
            
            List isExist = queries.select(STUDENTID, studentID);
            if (isExist.isEmpty()) {
                // The id field  will be created by the model
                Marks p = new Marks(studentID, assignment1, assignment2, exam, total, grade);
                int result = queries.command(INSERT, p);
                if (result == 1) {
                    view.displayMessage("Person added");
                    view.displayOneArea(p);
                } else {
                    view.displayMessage("Person not added");
                }
                view.setBrowsing(false);                
            } else {
                view.displayInputError("Warning: " 
                        + studentID + " already exists in the database.\n" 
                        + "Use 'Update All Records' to update record.");
            }
                        
        } catch (QueryException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }
    
    public void update(String studentID, int assignment1, int assignment2, int exam, int total, String grade) throws IllegalArgumentException {
        // No checking is performed for parameters being null, as this constitutes 
        // a programming error and having the program crash (with a stack trace) 
        // is reasonable in this case.
        if (studentID.equals("") || assignment1 == 0 || assignment2 == 0 || exam == 0 || total == 0 || grade.equals("")) {
            throw new IllegalArgumentException("Arguments must not contain an empty string");
        }
        try {
            
            // The id field  will be created by the model
            Marks p = new Marks(studentID, assignment1, assignment2, exam, total, grade);
            int result = queries.command(UPDATE, p);
            if (result == 1) {
                view.displayMessage("Mark for " + studentID + " updated.");
                view.displayOneArea(p);
            } else {
                view.displayMessage("Mark for " + studentID + " updated.");
            }
            view.setBrowsing(true);      
                        
        } catch (QueryException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }
            
    /************************************/
    /*          FIELD CHECKING          */
    /************************************/
    
    /**
     * Set the browsing context to contain all records in the address book with 
     * a specified last name. Display he first record or an error message if no 
     * records are found.
     * @param studentID id of student
     * @param assignment1 assignment 1
     * @param assignment2 assignment 2
     * @param exam exam
     * @param total total of all assessments
     * @param grade computation of all assessments
     * @return safe to verify that all potential errors are clear
     * @throws IllegalArgumentException if any of the parameters are empty strings
     */
    
    
    public boolean checkFields(String studentID, String assignment1, String assignment2, String exam, String total, String grade) {
        boolean safe = true;
        if (studentID.length() != 8) {
            view.displayInputError("Warning: Student ID must be 8 characters long\nExample: 12345678");
            safe = false;
        }
        try {
            int a1 = Integer.parseInt(assignment1);
            if (a1 > 20) {
                view.displayInputError("Warning: Max score for assignment 1 is 20");
                safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Assignment 1 score must be a number from 0-20");
            safe = false;
        }
        
        try {
            int a2 = Integer.parseInt(assignment2);
            if (a2 > 30) {
                view.displayInputError("Warning: Max score for assignment 2 is 30");
                safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Assignment 2 score must be a number from 0-30");
            safe = false;
        }
        
        try {
            int e = Integer.parseInt(exam);
            if (e > 50) {
                view.displayInputError("Warning: Max score for exam is 50");
                safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Exam score must be a number from 0-50");
            safe = false;
        }
        
        if (grade.equals("")) {
            view.displayInputError("Warning: Must compute first before saving records");
            safe = false;
        }
        
        return safe;
    }
    
    public boolean checkComputeFields(String assignment1, String assignment2, String exam) {
        boolean safe = true;
        try {
            int a1 = Integer.parseInt(assignment1);
            if (a1 > 20) {
                view.displayInputError("Warning: Max score for assignment 1 is 20");
                safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Assignment 1 score must be a number from 0-20");
            safe = false;
        }
        
        try {
            int a2 = Integer.parseInt(assignment2);
            if (a2 > 30) {
                view.displayInputError("Warning: Max score for assignment 2 is 30");
                safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Assignment 2 score must be a number from 0-30");
            safe = false;
        }
        
        try {
            int e = Integer.parseInt(exam);
            if (e > 50) {
                view.displayInputError("Warning: Max score for exam is 50");
                safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Exam score must be a number from 0-50");
            safe = false;
        }
        
        return safe;
    }
    
    public boolean checkToleranceField(String tolerance) {
        boolean safe = true;
        try {
            int t = Integer.parseInt(tolerance);
            if (t == 0) {
                view.displayInputError("Warning: Tolerance must not be 0");
            safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Tolerance must be a number");
            safe = false;
        }        
        return safe;
    }
    
    public boolean checkRangeField(String rFrom, String rTo) {
        boolean safe = true;
        try {
            int rf = Integer.parseInt(rFrom);
            if (rf == 0) {
                view.displayInputError("Warning: Range from must not be 0");
            safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Range from must be a number");
            safe = false;
        } 
        
        try {
            int rt = Integer.parseInt(rTo);
            if (rt == 0) {
                view.displayInputError("Warning: Range to must not be 0");
            safe = false;
            }
        } catch (NumberFormatException e) {
            view.displayInputError("Warning: Range to must be a number");
            safe = false;
        } 
        
        return safe;
    }
    
    
    /****************************************/
    /*          COMPUTATION METHOD          */
    /****************************************/
    
     /**
     * Set the browsing context to contain all records in the address book with 
     * a specified last name. Display he first record or an error message if no 
     * records are found.
     * @param studentID id of student
     * @param assignment1 assignment 1
     * @param assignment2 assignment 2
     * @param exam exam
     * @throws IllegalArgumentException if any of the parameters are empty strings
     */
    
    public void inputComputation(String studentID, int assignment1, int assignment2, int exam) {
        int totalGrade = assignment1 + assignment2 + exam;
        String gradeResult = "";
        if (totalGrade >= 50 ) {
            if (totalGrade >= 85) {
                gradeResult = "HD";
            } else if (totalGrade < 85 && totalGrade >= 75) {
                gradeResult = "D";
            } else if (totalGrade < 75 && totalGrade >= 65) {
                gradeResult = "C";
            } else if (totalGrade < 65 && totalGrade >= 50) {
                gradeResult = "P";
            }
        } else if (totalGrade < 50 && totalGrade >= 45) {
            if (exam < 25) {
                gradeResult = "SE";
            } else if (assignment1 < 10 || assignment2 < 15) {
                gradeResult = "SA";
            }
        } else {
            gradeResult = "F";
        }
        
        Marks m = new Marks(studentID, assignment1, assignment2, exam, totalGrade, gradeResult);
        view.computeResults(totalGrade, gradeResult);
        view.displayOneArea(m);
    }

    /**
     *  Close the address book.
     */
    public void close() {
        try {
            connector.disconnect();
        } catch (ConnectionException e) {
            view.displayError(e.getMessage());
            System.exit(1);
        }
    }
}
