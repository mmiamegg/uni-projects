/**
 * File name: ComputeTask.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/

import java.io.*;

public enum ComputeTask implements Serializable{

	PI ("Calculate Pi"),
	PRIME ("Calculate Prime"),
	GCD ("Calculate the Greatest Common Divisor");

	private String className;

	ComputeTask(String name) {
		this.className = name;
	}

	public ComputeTask getPI() {
		return PI;
	}

	public ComputeTask getPRIME() {
		return PRIME;
	}

	public ComputeTask getGCD() {
		return GCD;
	}

	public static String getClassName(String s) {
		String name = null;
		switch(s) {
			case "Calculate Pi": name = "CalculatePi"; break;
			case "Calculate Prime": name = "CalculatePrime"; break;
			case "Calculate the Greatest Common Divisor": name = "CalculateGCD"; break;
		}
		return name;
	} 
}