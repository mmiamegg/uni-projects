/**
 * File name: CSMessage.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.io.*;

public class CSMessage implements Task, Serializable {
	private String msg;
	private Object finalResult;

	// Constructor with parameter
	public CSMessage(String msg) {
		this.msg = msg;
	}

	// Reference of Task method
	@Override
	public void executeTask() {
		finalResult = msg;
	}

	// Reference of Task method
	@Override
	public Object getResult() {
		return finalResult;
	}

	public String getClassName(){
		return null;
	}
}