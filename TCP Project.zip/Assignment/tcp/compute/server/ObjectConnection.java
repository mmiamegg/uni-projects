/**
 * File name: ObjectConnection.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.net.*;
import java.io.*;

public class ObjectConnection extends Thread {
	private Socket clientSocket;
	private ObjectInputStream objectInputStream;
	private ObjectOutputStream objectOutputStream;
    private String className;

    // Constructor with parameter
	public ObjectConnection(Socket clientSocket) {
		try {
            // get socket details from client
			this.clientSocket = clientSocket;

            // create a stream to receive files to from client
			this.objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
			this.objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
		} catch(IOException e) {
			System.out.println("Error whe getting streams " + e.getMessage());
		}
	}

	@Override
	public void run() {
		Task task;
		try {
            // Object from client is deserialized
			task = (Task) objectInputStream.readObject();

            // Get class name
            className = task.getClassName();
            
            System.out.println("Performing a client task of " + className + "!");
			
            // Server executes task and performs calculation
            task.executeTask();

            // Object of the task calculated is serialized and sent back to client
			objectOutputStream.writeObject(task);
			
		} catch (EOFException e){
            System.out.println("EOFException:" + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IOException:" + e.getMessage());
            e.printStackTrace();        
        } catch (ClassNotFoundException e){
        	System.out.println("The compute-file cannot be found!");            
            try {
                // Create custom error message to send to client in place of original error message
                // task = new CSMessage("Please upload the compute-task before calling the server.");
                // Set message to result
                task = new CSMessage("Please upload the compute-task before calling the server.");
                task.executeTask();

                // serialize the result and send to client
                objectOutputStream.writeObject(task);
            } catch (IOException ex) {
                System.out.println("Error when closing the socket:" + ex.getMessage());
                ex.printStackTrace();
            }           
        } finally {
            if (clientSocket != null) {
                try {
                    clientSocket.close();
                } catch (IOException e){
                    System.out.println("Error when closing the socket:" + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
	}
}