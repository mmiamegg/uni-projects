package marks;

import marks.model.MarksModel;
import marks.presenter.MarksPresenter;
import marks.view.MarksView;
import marks.model.ConnectionException;

/**
 * MarksMVP is the application class for a refactoring to MVP of the example
 presented in Chapter 29 of Deitel Deitel (2012), 'Java How to Program Ninth
 * Edition', Prentice Hall.
 *
 * @author Mia Megan Gail Macasero (12127091)
 */
public class MarksMVP {

    public static void main(String args[]) {
        // Create the model. Exit the amplication if connection be made to the 
        // address book.
        MarksModel mm = new MarksModel();
        try {
            // do this via a GUI start button?
            mm.connect();
            mm.initialise();
        } catch (ConnectionException e) {
            System.err.println( e.getMessage());
            e.getCause().printStackTrace();
            System.exit(1);
        }
        // Create the presenter and view and inject their dependencies. Note 
        // there is a circular dependency beetween the presenter and the view, so
        // an explicit binding method (bind()) is required.
        MarksPresenter mp = new MarksPresenter(mm, mm);
        MarksView mv = new MarksView(mp);        
        mp.bind(mv);
        // Start the application
        mv.setVisible(true);
    }
}
