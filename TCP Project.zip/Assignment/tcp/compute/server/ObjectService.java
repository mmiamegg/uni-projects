/**
 * File name: ObjectService.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.net.*;
import java.io.*;

public class ObjectService extends Thread{
	private int serverPort;

	// Constructor with parameter
	public ObjectService(int serverPort){
		this.serverPort = serverPort;
	}

	public void run(){
		try {
			// create a socket for server details
			ServerSocket serverSocket = new ServerSocket(serverPort);
			System.out.println("------------------------------");
			System.out.println("The server is listening on port 6789 for object transfer...");
			
			while (true) {
				// accept a connection request from client on the same port
				Socket socket = serverSocket.accept();

				// make aconnection from client to server
				ObjectConnection connection = new ObjectConnection(socket);
				connection.start();
			}
		} catch (IOException e){
			System.out.println("Error when listening to a connection" + e.getMessage());
			e.printStackTrace();
		}	
	}
}