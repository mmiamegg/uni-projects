package marks.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.EnumMap;

/**
 * Will handle all database related functionality to a mark
 *
 * @author Mia Megan Gail Macasero (12127091)
 */

public class MarksModel implements IConnect, IQuery<MarksModel.Query, Marks> {    
    
    // specifies the queries supported by this program
    public static enum Query {
        INSERT, UPDATE, ALL, STUDENTID, TOLERANCE,RANGE
    };

    // Database details for the address book being managed
    private static final String URL = "jdbc:derby://localhost:1527/grades";
    private static final String USERNAME = "user";
    private static final String PASSWORD = "user";

    // map queries to the sql commands
    private EnumMap<Query, String> sqlCommands = 
        new EnumMap<>( MarksModel.Query.class );
    private EnumMap<Query, PreparedStatement> statements = 
        new EnumMap<>( MarksModel.Query.class );

    // The connection to the marks database
    private Connection connection = null;

    // the instance of mark
    public MarksModel() {
        // Specify the queries that are supported
        sqlCommands.put( Query.ALL, 
            "SELECT * FROM Marks" );
        sqlCommands.put( Query.STUDENTID, 
            "SELECT * FROM Marks WHERE studentID = ?" );
        sqlCommands.put( Query.INSERT, 
            "INSERT INTO Marks ( studentID, assignment1, assignment2, exam, total, grade ) VALUES ( ?, ?, ?, ?, ?, ? )" );
        sqlCommands.put( Query.UPDATE, 
            "UPDATE Marks SET assignment1=?, assignment2=?, exam=?, Total=?, grade=? WHERE studentID=?" );
        sqlCommands.put( Query.TOLERANCE, 
            "SELECT * FROM Marks WHERE " +
                "(total >= (85-?) and total <85) or " +
                "(total >= (75-?) and total <75) or " +
                "(total >= (65-?) and total <65) or " +
                "(total >= (50-?) and total <50) " +
                "ORDER BY total" );
        sqlCommands.put (Query.RANGE,
            "SELECT * FROM Marks WHERE (total >= ? AND total <= ?) ORDER BY total");
    }
    
    // IConnct implementation

    /**
     * Connect to the marks table
     * @throws ConnectionException  for catching exceptions
     */ 
    @Override
    public void connect() throws ConnectionException {
        // Connect to the address book database
        try {
        connection = DriverManager.getConnection( URL, USERNAME, PASSWORD );
        } catch(SQLException e ) {
            throw new ConnectionException("Unable to open data source",e);
        }
    }

    /**
     * Perform any initialization that is needed before queries can be
     * performed.
     *
     * @throws ConnectionException for catching exceptions
     */
    @Override
    public void initialise() throws ConnectionException {
        // Create prepared statements for each query
        try {
            for (Query q : Query.values()) {
                statements.put(q, connection.prepareStatement(sqlCommands.get(q)));
            }
        } catch (SQLException e) {
            throw new ConnectionException("Unable to initialise data source",e);
        }
    }

    /**
     * Disconnect from the marks table
     *
     * @throws ConnectionException for catching exceptions
     */
    @Override
    public void disconnect() throws ConnectionException {
        // Close the connection 
        // In Java 9, we can do try( connection ), but I am running Java 8
        try (Connection c = connection) {
            // connection is closed automatically with try with resources
            // close prepared statements first
            for (Query q : Query.values()) {
                statements.get(q).close();
            }
        } catch (SQLException e) {
            throw new ConnectionException("Unable to close data source",e);
        }
    }

    // IQuery implementation
    
    /**
     * Perform a selection on the marks table
     * @param q the selection as specified in the Query enum
     * @param p parameters for the query specified as a varags of type Object
     * @return a List of Marks objects that match query specification
     * @throws QueryException  for catching exceptions
     */
    
    @Override
    public List<Marks> select( Query q, Object... p ) throws QueryException {
        switch ( q ) {
            case ALL:
                return getAllMarks();
            case STUDENTID:
                return getMarkByID( (String) p[0] );
            case TOLERANCE:
                return getMarkByTolerance ((int) p[0] );
            case RANGE:
                return getMarkByRange ((int) p[0], (int) p[1]);
        }
        // Should never happen
        return null;
    }

    /**
     * Perform a command (insert, delete, update ... ) on the marks table
     * @param q the command as specified in the Query enum
     * @param m a Marks object containing the data for the command
     * @return the number of records in the marks table impacted on by the command
     * @throws QueryException  for catching exceptions
     */
    @Override
    public int command( Query q, Marks m ) throws QueryException {
        switch ( q ) {
            case INSERT:
                return addMark( m );
            case UPDATE:
                return updateMark( m );
        }
        // Should never happen
        return -1;
    }

    private Marks createMark(ResultSet rs) throws QueryException {
        Marks m = null;
        try {
            m = new Marks(
                    rs.getString("studentID"),
                    rs.getInt("assignment1"),
                    rs.getInt("assignment2"),
                    rs.getInt("exam"),
                    rs.getInt("total"),
                    rs.getString("grade")
            );
        } catch (SQLException e) {
            throw (new QueryException("Unable to process the result of selection query",e));
        }
        return m;
    }
    
    // Helper methods

    /*
     * Select all of the entries in the marks table
     */
    private List< Marks> getAllMarks() throws QueryException {
        // get prepared statement
        PreparedStatement ps = statements.get(Query.ALL);
        // executeQuery returns ResultSet containing matching entries
        // try with resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(createMark(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }    

    /*
     * Select Marks by Student ID
     */
    private List< Marks> getMarkByID(String studentID) throws QueryException {
        // Look up prepared statement
        PreparedStatement ps = statements.get(Query.STUDENTID);
        try {
            // Insert studentID into prepared statement
            ps.setString(1, studentID);
        } catch (SQLException e) {
            throw (new QueryException("Unable to paramaterise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with 
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(createMark(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }
    
        private List< Marks> getMarkByTolerance(int tolerance) throws QueryException {
        // Look up prepared statement
        PreparedStatement ps = statements.get(Query.TOLERANCE);
        try {
            // use variable to look for the tolerance for each grade
            ps.setInt(1, tolerance);
            ps.setInt(2, tolerance);
            ps.setInt(3, tolerance);
            ps.setInt(4, tolerance);
        } catch (SQLException e) {
            throw (new QueryException("Unable to paramaterise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with 
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(createMark(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }
        
    private List< Marks> getMarkByRange(int rFrom, int rTo) throws QueryException {
        // Look up prepared statement
        PreparedStatement ps = statements.get(Query.RANGE);
        try {
            // Insert last name into prepared statement
            ps.setInt(1, rFrom);
            ps.setInt(2, rTo);
        } catch (SQLException e) {
            throw (new QueryException("Unable to paramaterise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with 
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(createMark(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }

    /*
     * Add a record to the address book. Record fields are extracted from the method
     * parameter, which is a Marks object. The id field (typically set to -1) is
     * ignored - it will be autogenerated by the address book.    
     */
    private int addMark(Marks m) throws QueryException {
        // Look up prepared statement
        PreparedStatement ps = statements.get(Query.INSERT);
        // insert person attributes into prepared statement
        try {
            ps.setString(1, m.getStudentID());
            ps.setInt(2, m.getAssignment1());
            ps.setInt(3, m.getAssignment2());
            ps.setInt(4, m.getExam());
            ps.setInt(5, m.getTotal());
            ps.setString(6, m.getGrade());
        } catch (SQLException e) {
            throw (new QueryException("Unable to paramaterise selection query", e));
        }
        // insert the new entry; returns # of rows updated
        try {
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw (new QueryException("Unable to perform insert command", e));
        }
    }
    
    private int updateMark(Marks m) throws QueryException {
        // Look up prepared statement
        PreparedStatement ps = statements.get(Query.UPDATE);
        // insert person attributes into prepared statement
        try {
            ps.setInt(1, m.getAssignment1());
            ps.setInt(2, m.getAssignment2());
            ps.setInt(3, m.getExam());
            ps.setInt(4, m.getTotal());
            ps.setString(5, m.getGrade());
            ps.setString(6, m.getStudentID());
        } catch (SQLException e) {
            throw (new QueryException("Unable to paramaterise selection query", e));
        }
        // insert the new entry; returns # of rows updated
        try {
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw (new QueryException("Unable to perform insert command", e));
        }
    }
}
