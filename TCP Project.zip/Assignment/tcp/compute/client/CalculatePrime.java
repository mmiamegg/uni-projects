/**
 * File name: CalculatePrime.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.io.*;
import java.util.*;

public class CalculatePrime implements Task, Serializable{
	private int inputNumber;
	private boolean isPrimeNum;
	private List<Integer> primeNumbers;
	private Object result;
	private String primes;
	private String className = "CalculatePrime";

	// Constructor with parameter
	public CalculatePrime(int number){
		this.inputNumber = number;
	}

	// Check if number is prime
	public boolean isPrime(int num) {
		for (int i = 2; i <= num/2; i++) {
			if (num % i == 0) {
				this.isPrimeNum = false;
			} else {
				this.isPrimeNum = true;
			}
		}
		this.result = isPrimeNum;
		return isPrimeNum;
	}	

	// Set Value of result
	@Override
	public void executeTask() {
		primeNumbers = new LinkedList<>();
		if (inputNumber >= 3) {
			primeNumbers.add(2);
			primeNumbers.add(3);
		}
		for (int i = 3; i <= inputNumber; i++) {
			if  (isPrime(i) == true) {
				primeNumbers.add(i);
			}
		}
		this.primes = primeNumbers.toString().replace("[", "").replace("]","");
		this.result = primeNumbers;
	}

	// method call to retrieve result
	@Override
	public Object getResult() {
		result = "The number of primes are: " + primeNumbers.size() + " and they are: " + primes;		
		return result;
	}

	public String getClassName(){
		return className;
	}

}