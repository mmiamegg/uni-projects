/**
 * File name: TCPClientObject.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.net.*;
import java.io.*;

public class TCPClientObject {
    String serverIP;
    int objectServerPort;
    int fileServerPort;
    Socket objectSocket;
    Socket fileSocket;
    Object result;

    // Constructor with parameter set values when method is called
    public TCPClientObject(String ip, int object, int file){
        this.serverIP = ip;
        this.objectServerPort = object;
        this.fileServerPort = file;
    }

    // method to send select object to server
    public void sendObject(Task computeTask) {		                
        // try catch to capture all errors and display them on command line
        try {
            // create a socket for server details				
            objectSocket = new Socket(serverIP, objectServerPort);

            // create a stream to send files to server using server socket details
            OutputStream objectSocketOutputStream = objectSocket.getOutputStream();
            ObjectOutputStream objectOutputStream  = new ObjectOutputStream(objectSocketOutputStream);

            // create a reference of the compute-task object passed by the parameter
            Task task = computeTask;
            // serializing an object of a task
            objectOutputStream.writeObject(task);

            // create a stream to receive files from server using server socket details
            InputStream socketInputStream = objectSocket.getInputStream();
            ObjectInputStream objectInputStream = new ObjectInputStream(socketInputStream);

            // deserializing an object of a task
            task = (Task) objectInputStream.readObject();
            
            //assign the result to local method for GUI to call
            this.result = task.getResult();
        } catch (UnknownHostException e) {
            System.out.println("UnknownHostException:" + e.getMessage());
            e.printStackTrace();
        } catch (EOFException e){
            System.out.println("EOF error:" + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IOException:" + e.getMessage());
            e.printStackTrace();		
        } catch (ClassNotFoundException e){
            System.out.println("The concrete class of the interface Task is not found: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (objectSocket != null) {
                 try {
                     objectSocket.close();
                } catch (IOException e) {
                     System.out.println("Error when closing the socket:" + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }

    // pass received variable to GUI
    public Object getResult() {
            return result;
    }
    
}