/**
 * File name: FileConnection.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.net.*;
import java.io.*;

public class FileConnection extends Thread {
	private Socket clientSocket;
    private InputStream objectInputStream;
    private OutputStream objectOutputStream;
       	
	public FileConnection (Socket clientSocket) {
        try {
            // get socket details from client
            this.clientSocket = clientSocket;

            // create a stream to receive files to from client
            this.objectInputStream = clientSocket.getInputStream();
            this.objectOutputStream = clientSocket.getOutputStream();
        } catch(IOException e) {
            System.out.println("Error whe getting streams " + e.getMessage());
        }
	}
	
    @Override
	public void run(){
        String ClassName = new String();
        while (true) {	
            try {			                
            //Construct data input stream to receive class files
            DataInputStream clientData = new DataInputStream(objectInputStream);
            //Receive the class file name
            ClassName = clientData.readUTF();
            //Receive the class file length
            int size = clientData.readInt();
            //Construct a byte array to receive the class file
            byte[] buffer = new byte[size];
            int bytesRead = clientData.read(buffer, 0, buffer.length);
            //Construct a file output stream to save the class file
            FileOutputStream fo=new FileOutputStream(ClassName);
            BufferedOutputStream bos = new BufferedOutputStream(fo);
            bos.write(buffer,0,bytesRead);
            bos.close();
            System.out.println("The class file of "+ClassName+" has been uploaded.");
        	} catch (EOFException e) {
                System.out.println("EOF"+e.getMessage());
                break;
            } catch (FileNotFoundException e) {
                System.out.println("File "+ClassName+" cannot find.");
                break;
            } catch (SocketException e) {
                System.out.println("Client closed.");
                break;
            } catch(IOException e) {
                e.printStackTrace();
                break;
            } 
        }
    }
}