package marks.view;
import marks.model.Marks;
import java.util.List;

/**
 * IView provides a generic interface for the display of browsable records
 * @author Mia Megan Gail Macasero (12127091)
 * @param <T> the type for the record that is to be displayed
 */
public interface IView<T> {
    void displayRecord( T r);
    void displayMessage( String m );
    void setBrowsing( boolean b );
    void displayError( String e );
    void displayInputError ( String e);
    void displayAllArea( List<Marks> m);
    void displayOneArea( Marks m);
    void computeResults (int t, String g);
}

