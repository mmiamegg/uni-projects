package marks.model;

import marks.model.ConnectionException;

/**
 * IConnect provides methods for managing a connection to a data source.
 *
 * @author Mia Megan Gail Macasero (12127091)
 */
public interface IConnect {

    /**
     * Establish a connection to the data source being managed
     * @throws ConnectionException for catching exceptions
     */
    public void connect() throws ConnectionException;

    /**
     * Initialise the connection being managed. If the data source is a
     * database, queries are constructed at this point
     * @throws ConnectionException  for catching exceptions
     */
    public void initialise() throws ConnectionException;

    /**
     * Disestablish the connection being managed
     * @throws ConnectionException for catching exceptions
     */
    public void disconnect() throws ConnectionException;
}
