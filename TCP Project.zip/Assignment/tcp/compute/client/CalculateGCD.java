/**
 * File name: CalculateGCD.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.io.*;

public class CalculateGCD implements Task, Serializable {
	private int num1;
	private int num2;
	private Object result;
	private String className = "CalculateGCD";

	// Constructor with parameter
	public CalculateGCD (int a, int b) {
		this.num1 = a;
		this.num2 = b;
	}
	
	// set value of result
	@Override
	public void executeTask() {
		for (int i =1; i <= num1 && i <= num2; i++) {
			if (num1 % i == 0 && num2 % i == 0) {
				this.result = i;
			}
		}
	}

	// method call to retrieve result
	@Override
	public Object getResult() {
		result = "The Greates Common Divisor of " + num1 + " and " + num2 + " is " + result;	
		return result;
	}

	public String getClassName(){
		return className;
	}
}