/**
 * File name: TCPClientFile.java
 * @author mia megan gail macasero 12127091
 * @lecturer: li, wei
 * @tutor: huynh, tan dat
 * compiled and built on CMD using JDK 1.8
 * Java SWING (Created in netbeans 8.2 and copied to text editor)
 * This class is part of a submission for Assignment 1 of
 * COIT20257 Distributed Systems: Principles and Development
 **/ 

import java.net.*;
import java.io.*;

public class TCPClientFile {
    String serverIP;
    int objectServerPort;
    int fileServerPort;
    Socket objectSocket;
    Socket fileSocket;
    Object result;

    // Constructor with parameter set values when method is called
    public TCPClientFile(String ip, int object, int file){
        this.serverIP = ip;
        this.objectServerPort = object;
        this.fileServerPort = file;
    }

    // method to send select file to server
    public void sendFile(String computeTask) {		        
        try {				
            // create a socket for server details
            fileSocket = new Socket(serverIP, fileServerPort);

            // create a stream to send files to server using server socket details
            OutputStream objectSocketOutputStream = fileSocket.getOutputStream();

            //Retrieve the compute class name
            String ClassName = computeTask;    
            //Read the class file into a byte array
            File ClassFile = new File(ClassName);
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(ClassFile));
            DataInputStream dis = new DataInputStream(bis);   
            byte[] mybytearray = new byte[(int) ClassFile.length()]; 
            dis.readFully(mybytearray, 0, mybytearray.length);
            //Use a data output stream to send the class file
            DataOutputStream dos = new DataOutputStream(objectSocketOutputStream);
            //Send the class file name
            dos.writeUTF(ClassName);
            //Send the class file length
            dos.writeInt(mybytearray.length);
            //Send the class file
            dos.write(mybytearray, 0, mybytearray.length);   
            dos.flush();

            //Report the the transfer state and assign to method for GUI to call
            this.result =  "Uploading of " + computeTask + " is done.";
        } catch (UnknownHostException uhe) {
            System.out.println("UnknowHost:"+uhe.getMessage());
        } catch (IOException e) {
            System.out.println("IO errors:"+e.getMessage());
        }
    }

    // pass received variable to GUI
    public Object getResult() {
            return result;
    }    
}