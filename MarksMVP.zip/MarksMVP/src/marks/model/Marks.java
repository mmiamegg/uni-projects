package marks.model;

/**
 * The model for all mark fields to be used in the program
 *
 * @author Mia Megan Gail Macasero (12127091)
 */
public class Marks {

    private final String studentID;
    private final int assignment1;
    private final int assignment2;
    private final int exam;
    private final int total;
    private final String grade;

    /**
     * Create a data transfer object for a mark record. 
     *
     * @param studentID id of student
     * @param assignment1 assignment 1
     * @param assignment2 assignment 2
     * @param exam exam
     * @param total total of all assessments
     * @param grade computation of all assessments
     * 
     */
    public Marks(String studentID, int assignment1, int assignment2, int exam, int total, String grade) {
        this.studentID = studentID;
        this.assignment1 = assignment1;
        this.assignment2 = assignment2;
        this.exam = exam;
        this.total = total;
        this.grade = grade;
    }    
    
    // Getters. 
    
    /**
     * @return record identifier
     */
    public String getStudentID() {
        return studentID;
    }

    /**
     * @return assignment 1
     */
    public int getAssignment1() {
        return assignment1;
    }

    /**
     * @return assignment 2
     */
    public int getAssignment2() {
        return assignment2;
    }

    /**
     * @return exam
     */
    public int getExam() {
        return exam;
    }

    /**
     * @return total
     */
    public int getTotal() {
        return total;
    }
    
    /**
     * @return grade
     */
    public String getGrade() {
        return grade;
    }
}
