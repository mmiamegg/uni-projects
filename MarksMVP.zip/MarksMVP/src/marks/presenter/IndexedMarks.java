
package marks.presenter;

import marks.model.Marks;

/**
 * IndexedMarks provides a wrapper for a Marks record that provides
 information relating to its position in the browsing context maintained by
 PersonPresenter.
 *
 * @author Mia Megan Gail Macasero (12127091)
 */
public class IndexedMarks {

    private final Marks m;
    private final int i;
    private final int n;

    /**
     * Create a wrapper for a Marks object
     *
     * @param m the object to be wrapped
     * @param i the position of the object in the browsing context
     * @param n the number of objects in the browsing context
     */
    public IndexedMarks(Marks m, int i, int n) {
        this.m = m;
        this.i = i;
        this.n = n;
    }

    /**
     * @return the person object being wrapped
     */
    public Marks getMark() {
        return m;
    }

    /**
     * @return the position of the wrapped person object in the browsing context
     */
    public int getIndex() {
        return i;
    }

    /**
     * @return the number of objects in the browsing context
     */
    public int getSize() {
        return n;
    }
    
}
