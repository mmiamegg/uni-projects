package marks.model;

/**
 *
 * @author Dennis
 */
public class QueryException extends Exception {

    public QueryException(String message,Throwable cause) {
        super(message,cause);
    }
}
