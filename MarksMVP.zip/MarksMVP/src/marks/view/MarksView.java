package marks.view;

// Fig. 28.32: MarksView.java
// A simple address book
// Amended to conform to the MVP pattern by Dennis Jarvis July 2012

 /* @author Mia Megan Gail Macasero (12127091) */

import marks.presenter.MarksPresenter;
import marks.presenter.IndexedMarks;
import marks.model.Marks;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import java.util.List;

public class MarksView extends JFrame implements IView<IndexedMarks> {
    // the presenter for this view
    private MarksPresenter presenter;

    // Variables declaration - do not modify                     
    private JButton addButton;
    private JButton addOption;
    private JTextField addOptionTextField;
    private JTextField assignment1TextField;
    private JTextField assignment2TextField;
    private JButton computeButton;
    private JTextField examTextField;
    private JTextField gradeTextField;
    private JTextField indexTextField;
    private JLabel jLabel1;
    private JLabel jLabel10;
    private JLabel jLabel11;
    private JLabel jLabel12;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    private JPanel jPanel1;
    private JPanel jPanel2;
    private JPanel jPanel3;
    private JPanel jPanel4;
    private JPanel jPanel5;
    private JPanel jPanel7;
    private JScrollPane jScrollPane1;
    private JTextArea displayDataArea;
    private JTextField maxTextField;
    private JButton nextButton;
    private JButton previousButton;
    private JButton rangeButton;
    private JTextField rangeFromTextField;
    private JTextField rangeToTextField;
    private JComboBox<String> selectAddOptionButton;
    private JTextField studentIDTextField;
    private JButton toleranceButton;
    private JTextField toleranceTextField;
    private JTextField totalTextField;
    private JButton editAllButton;
    private JButton editOneButton;
    private JTextField editTextField;
    private JButton updateButton;
    // End of variables declaration 

    public MarksView( MarksPresenter pp ) {
        super("Marks Presenter");
        
        presenter = pp;

        // create GUI
         jPanel2 = new JPanel();
        jPanel4 = new JPanel();
        jLabel10 = new JLabel();
        toleranceTextField = new JTextField();
        toleranceButton = new JButton();
        rangeFromTextField = new JTextField();
        jLabel11 = new JLabel();
        rangeButton = new JButton();
        rangeToTextField = new JTextField();
        jLabel12 = new JLabel();
        jScrollPane1 = new JScrollPane();
        displayDataArea = new JTextArea();
        jPanel3 = new JPanel();
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        selectAddOptionButton = new JComboBox<>();
        addOption = new JButton();
        addOptionTextField = new JTextField();
        jPanel5 = new JPanel();
        previousButton = new JButton();
        nextButton = new JButton();
        indexTextField = new JTextField();
        maxTextField = new JTextField();
        jLabel2 = new JLabel();
        studentIDTextField = new JTextField();
        assignment1TextField = new JTextField();
        assignment2TextField = new JTextField();
        examTextField = new JTextField();
        totalTextField = new JTextField();
        gradeTextField = new JTextField();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jLabel6 = new JLabel();
        jLabel7 = new JLabel();
        jLabel8 = new JLabel();
        computeButton = new JButton();
        addButton = new JButton();
        jPanel7 = new JPanel();
        jLabel9 = new JLabel();
        editTextField = new JTextField();
        editOneButton = new JButton();
        editAllButton = new JButton();
        updateButton = new JButton();
        
        setSize(1050,700);
        setResizable(false);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBorder(BorderFactory.createTitledBorder("Output"));

        jPanel4.setBorder(BorderFactory.createTitledBorder("Search Options"));

        jLabel10.setText("Tolerance:");

        toleranceButton.setText("Find Tolerance");
        toleranceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                toleranceButtonActionPerformed(evt);
            }
        });

        jLabel11.setText("Range:");

        rangeButton.setText("Find Range");
        rangeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                rangeButtonActionPerformed(evt);
            }
        });

        jLabel12.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel12.setText("to");

        GroupLayout jPanel4Layout = new GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                    .addComponent(jLabel11, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(toleranceTextField)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(rangeFromTextField, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rangeToTextField, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(toleranceButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rangeButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(toleranceTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(toleranceButton))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(rangeFromTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(rangeButton)
                    .addComponent(rangeToTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        displayDataArea.setColumns(20);
        displayDataArea.setRows(5);
        jScrollPane1.setViewportView(displayDataArea);

        GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        jPanel3.setBorder(BorderFactory.createTitledBorder("Input"));

        jPanel1.setBorder(BorderFactory.createTitledBorder("Add Option: One or Many"));

        jLabel1.setText("Add Option: ");

        selectAddOptionButton.setModel(new DefaultComboBoxModel<>(new String[] { "Add One", "Add Many" }));

        addOption.setText("Add");
        addOption.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                addOptionButtonActionPerformed(evt);
            }
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(selectAddOptionButton, 0, 142, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(addOptionTextField, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(addOption)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(selectAddOptionButton, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(addOption)
                    .addComponent(addOptionTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(BorderFactory.createTitledBorder("Browse and Action"));

        previousButton.setText("Prev");
        previousButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                previousButtonActionPerformed(evt);
            }
        });

        nextButton.setText("Next");
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });

        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setText("of");

        jLabel3.setText("Student ID");

        jLabel4.setText("Assignment 1");

        jLabel5.setText("Assignment 2");

        jLabel6.setText("Exam");

        jLabel7.setText("Total");

        jLabel8.setText("Grades");

        computeButton.setText("Compute");
        computeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                computeButtonActionPerformed(evt);
            }
        });

        addButton.setText("Save New");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        updateButton.setText("Update All Records");
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        GroupLayout jPanel5Layout = new GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(computeButton, GroupLayout.PREFERRED_SIZE, 168, GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(previousButton, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(indexTextField, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                            .addComponent(totalTextField, GroupLayout.Alignment.LEADING)
                            .addComponent(examTextField, GroupLayout.Alignment.LEADING)
                            .addComponent(assignment2TextField, GroupLayout.Alignment.LEADING)
                            .addComponent(assignment1TextField, GroupLayout.Alignment.LEADING)
                            .addComponent(studentIDTextField, GroupLayout.Alignment.LEADING)
                            .addComponent(gradeTextField, GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(addButton, GroupLayout.PREFERRED_SIZE, 168, GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(maxTextField, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(nextButton, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)))
                        .addGap(40, 40, 40))))
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(updateButton, GroupLayout.PREFERRED_SIZE, 159, GroupLayout.PREFERRED_SIZE)
                .addGap(146, 146, 146))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(previousButton)
                    .addComponent(nextButton)
                    .addComponent(indexTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(maxTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(studentIDTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(assignment1TextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(assignment2TextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(examTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(totalTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(gradeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(computeButton)
                    .addComponent(addButton))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(updateButton)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(BorderFactory.createTitledBorder("Update Option: One or All"));

        jLabel9.setText("Student ID: ");

        editOneButton.setText("Edit");
        editOneButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                editOneButtonActionPerformed(evt);
            }
        });

        editAllButton.setText("Edit All Existing Records");
        editAllButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                editAllButtonActionPerformed(evt);
            }
        });

        GroupLayout jPanel7Layout = new GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(editAllButton, GroupLayout.DEFAULT_SIZE, 321, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(editTextField)
                        .addGap(18, 18, 18)
                        .addComponent(editOneButton)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(editTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(editOneButton))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editAllButton)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        GroupLayout jPanel3Layout = new GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jPanel7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

    //set fields to false
    indexTextField.setEditable(false);
    maxTextField.setEditable(false);
    
    studentIDTextField.setEditable(false);
    studentIDTextField.setEditable(false);
    assignment1TextField.setEditable(false);
    assignment2TextField.setEditable(false);
    examTextField.setEditable(false);
    totalTextField.setEditable(false);
    gradeTextField.setEditable(false);
    }

    /********************************************/
    /*          BROWSE FUNCTIONALITIES          */
    /********************************************/
    
    // handles call when previousButton is clicked
    private void previousButtonActionPerformed(ActionEvent evt) {
        presenter.showPrevious();
    }

    // handles call when nextButton is clicked
    private void nextButtonActionPerformed(ActionEvent evt) {
        presenter.showNext();
    }

    /*****************************************/
    /*          ADD FUNCTIONALITIES          */
    /*****************************************/

    // add button to set for adding one or more marks
    private void addOptionButtonActionPerformed(ActionEvent evt) {
        studentIDTextField.setEditable(true);
        assignment1TextField.setEditable(true);
        assignment2TextField.setEditable(true);
        examTextField.setEditable(true);
        
        studentIDTextField.setText("");
        assignment1TextField.setText("");
        assignment2TextField.setText("");
        examTextField.setText("");
        totalTextField.setText("");
        gradeTextField.setText("");
    } 
    
    // add button for adding data to the database
    private void addButtonActionPerformed(ActionEvent evt) {
        boolean safe;
        safe = presenter.checkFields(
            studentIDTextField.getText(),
            assignment1TextField.getText(),
            assignment2TextField.getText(),
            examTextField.getText(),
            totalTextField.getText(),
            gradeTextField.getText()
        );
        
        if (safe) {
            presenter.insert(
                studentIDTextField.getText().toString(),
                Integer.parseInt(assignment1TextField.getText()),
                Integer.parseInt(assignment2TextField.getText()),
                Integer.parseInt(examTextField.getText()),
                Integer.parseInt(totalTextField.getText()),
                gradeTextField.getText().toString()
            );            
        }
    }

    
    /******************************************/
    /*          EDIT FUNCTIONALITIES          */
    /******************************************/
    
    // select a specific mark to update on the input fields
    private void editOneButtonActionPerformed(ActionEvent evt) {
        studentIDTextField.setEditable(false);
        assignment1TextField.setEditable(true);
        assignment2TextField.setEditable(true);
        examTextField.setEditable(true);
        presenter.selectByStudentID( editTextField.getText() );
    }

    // select all the marks to edit on the input fields
    private void editAllButtonActionPerformed(ActionEvent evt) {
        studentIDTextField.setEditable(false);
        assignment1TextField.setEditable(true);
        assignment2TextField.setEditable(true);
        examTextField.setEditable(true);
        
        studentIDTextField.setEditable(false);
        presenter.selectAll();
    }
    
    // update fields to the database
    private void updateButtonActionPerformed(ActionEvent evt) {       
        boolean safe;
        safe = presenter.checkFields(
            studentIDTextField.getText(),
            assignment1TextField.getText(),
            assignment2TextField.getText(),
            examTextField.getText(),
            totalTextField.getText(),
            gradeTextField.getText()
        );
        
        computeButtonActionPerformed(evt);
        
        if (safe) {
            presenter.update(
                studentIDTextField.getText().toString(),
                Integer.parseInt(assignment1TextField.getText()),
                Integer.parseInt(assignment2TextField.getText()),
                Integer.parseInt(examTextField.getText()),
                Integer.parseInt(totalTextField.getText()),
                gradeTextField.getText().toString()
            );            
        }
    }  

                                        
    /****************************************************/
    /*          OUTPUT DISPLAY FUNCTIONALITIES          */
    /****************************************************/
    
    // display fields by tolerance
    private void toleranceButtonActionPerformed(ActionEvent evt) {                                         
        boolean safe;
        //field validation
        safe = presenter.checkToleranceField(
            toleranceTextField.getText()
        );
        //proceed with query process when no errors
        if (safe) {
            presenter.selectByTolerance(
                Integer.parseInt(toleranceTextField.getText())
            );                        
        }
        // clear textfield data
        toleranceTextField.setText("");
        
        assignment1TextField.setEditable(true);
        assignment2TextField.setEditable(true);
        examTextField.setEditable(true);
    }                                        
    
    // display fields by range
    private void rangeButtonActionPerformed(ActionEvent evt) {                                         
        boolean safe;
        //field validation
        safe = presenter.checkRangeField(
            rangeFromTextField.getText(),
            rangeToTextField.getText()    
        );
        //proceed with query process when no errors
        if (safe) {
            presenter.selectByRange(
                Integer.parseInt(rangeFromTextField.getText()),
                Integer.parseInt(rangeToTextField.getText())
            );                        
        }
        // clear textfield data
        rangeFromTextField.setText("");
        rangeToTextField.setText("");
        
        assignment1TextField.setEditable(true);
        assignment2TextField.setEditable(true);
        examTextField.setEditable(true);
    }
    
    /*******************************************/
    /*          COMPUTE FUNCTIONALITY          */
    /*******************************************/
    
    private void computeButtonActionPerformed(ActionEvent evt) {                                                  
        boolean safe;
        //field validation
        safe = presenter.checkComputeFields(
            assignment1TextField.getText(),
            assignment2TextField.getText(),
            examTextField.getText() 
        );
        //proceed with query process when no errors
        if (safe) {
            presenter.inputComputation(
                studentIDTextField.getText(),
                Integer.parseInt(assignment1TextField.getText()),
                Integer.parseInt(assignment2TextField.getText()),
                Integer.parseInt(examTextField.getText())
            );                        
        }
    }
    

    
    /***********************************************/
    /*          INTERFACE IMPLEMENTATIONS          */
    /***********************************************/

    @Override
    public void displayRecord( IndexedMarks im ) {
        Marks m = im.getMark();
        studentIDTextField.setText( m.getStudentID() );
        assignment1TextField.setText ( Integer.toString(m.getAssignment1()) );
        assignment2TextField.setText( Integer.toString(m.getAssignment2()) );
        examTextField.setText( Integer.toString(m.getExam()) );
        totalTextField.setText( Integer.toString(m.getTotal()) );
        gradeTextField.setText( m.getGrade() );

        maxTextField.setText( Integer.toString( im.getSize() ) );
        indexTextField.setText(Integer.toString( im.getIndex() ) );
    }

    @Override
    public void setBrowsing( boolean flag ) {
        nextButton.setEnabled( flag );
        previousButton.setEnabled( flag );
    }

    @Override
    public void displayMessage(String s) {
        JOptionPane.showMessageDialog(this, s, "Message", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public void displayError(String s) {
        System.err.println(s);
    }
    
    @Override
    public void displayInputError(String s) {
        JOptionPane.showMessageDialog(this, s, "Message", JOptionPane.ERROR_MESSAGE);
    }
    
    
    /***************************************/
    /*          TEXT AREA DISPLAY          */
    /***************************************/    
        
    @Override
    public void displayAllArea( List<Marks> m ) {
        displayDataArea.setText(String.format("|%15s|%15s|%15s|%10s|%10s|%10s|\n", 
                "Student ID", "Assignment1", "Assignment 2",
                "Exam", "Total", "Grade"));
        for(Marks marks : m) {
            displayDataArea.append(String.format("|%14s|%25d|%25d|%14d|%11d|%15s|\n", 
                marks.getStudentID(), marks.getAssignment1(), marks.getAssignment2(), 
                marks.getExam(), marks.getTotal(), marks.getGrade()));
        }        
    }
    
    @Override
    public void displayOneArea( Marks marks ) {
        displayDataArea.setText(String.format("|%15s|%15s|%15s|%10s|%10s|%10s|\n", 
                "Student ID", "Assignment1", "Assignment 2",
                "Exam", "Total", "Grade"));

        displayDataArea.append(String.format("|%14s|%25d|%25d|%14d|%11d|%15s|\n", 
                marks.getStudentID(), marks.getAssignment1(), marks.getAssignment2(), 
                marks.getExam(), marks.getTotal(), marks.getGrade()));        
    }
    
    
    /*********************************************************/
    /*          COMPUTE RESULTS TO RESPECTIVE FIELDS         */
    /*********************************************************/   
        
    @Override
    public void computeResults(int total, String grade) {
        totalTextField.setText(Integer.toString(total));
        gradeTextField.setText(grade);
    }
}
